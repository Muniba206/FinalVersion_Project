import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Login implements ActionListener

{	
	//JDBC objects
			Connection con;
			Statement st;
			ResultSet rs;
			
			//Login Field
			private JFrame frame;
			private JLabel username;
			private JLabel password;
			private JTextField usernamefield;
			private JPasswordField passwordfield;
			private JButton signinbutton;
			private JButton signupbutton;
			private JPanel loginpanel;
			private JPanel mainpanel;
			private JPanel imagepanel;
			
			//Register Field
			private JPanel registerpanel;
			private JLabel registernumber;
			private JTextField registerfield;
			private JLabel firstname;
			private JLabel lastname;
			private JTextField fnamefield;
			private JTextField lnamefield;
			private JLabel r_username;
			private JLabel r_password;
			private JLabel email;
			private JTextField r_usernamefield;
			private JTextField r_passwordfield;
			private JTextField emailfield;
			private JLabel space;
			private JButton savebutton;
			private ImageIcon image;
			private JLabel label;
						
			public Login(){
				createRegisterTables();
				createAuthenView();
				mainframe();
				
			}
			
			private void mainframe() {
				
				//Set start frame for user login
				frame = new JFrame ("Multiple Chat System");
				try{
					frame.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:/Users/dechen olesen/Desktop/chatroom1.jpg")))));
				}catch (IOException e){
					System.out.println("Image doesn't exist");
				}
				frame.setPreferredSize(new Dimension(600,500));
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
				
				//Panel for login layout	
				mainpanel = new JPanel();
				mainpanel.setPreferredSize(new Dimension(350, 100));
		        mainpanel.setBackground(Color.CYAN);  
				loginpanel = new JPanel(new GridLayout(3, 3));
				username = new JLabel("Username");
				password = new JLabel("Password");
				usernamefield = new JTextField(15);
				passwordfield = new JPasswordField(15);
				signinbutton = new JButton("SIGN IN");
				signinbutton.addActionListener(this);
				signupbutton = new JButton("SIGN UP");
				signupbutton.addActionListener(new RegisterButton());
				
				loginpanel.add(username);
				loginpanel.add(usernamefield);
				loginpanel.add(password);
				loginpanel.add(passwordfield);		
				loginpanel.add(signupbutton);
				loginpanel.add(signinbutton);
				mainpanel.add(loginpanel);
				
				//Register layout
				registerpanel = new JPanel(new GridLayout(7, 7));
				registernumber = new JLabel("Register No.");
				registerfield = new JTextField(15);
				firstname = new JLabel("First Name");
				lastname = new JLabel("Last Name");
				fnamefield = new JTextField(15);
				lnamefield = new JTextField(15);
				r_username = new JLabel("Username");
				r_password = new JLabel("Password");
				r_usernamefield = new JTextField(15);
				r_passwordfield = new JTextField(15);
				email = new JLabel("Email");
				emailfield = new JTextField(15);
				space = new JLabel("");
				savebutton = new JButton("SAVE");
				savebutton.setBackground(Color.CYAN);
				savebutton.addActionListener(new InsertButton());
				
				frame.add(mainpanel);
				frame.setLayout(new GridBagLayout());
		        frame.add(mainpanel, new GridBagConstraints());
				frame.setVisible(true);
				frame.pack();
				frame.setLocationRelativeTo(null);		
				frame.setResizable(false);
		
			}
	
	private void connect() {
		
		try {
			
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/multichatsystem", "root", "lobsang123#" );			
			st = con.createStatement();			
			//st.executeUpdate("CREATE DATABASE multichatsystem");
		
				} 
				catch(Exception ex){		
			}				
		}
	
		// this method Creating the database tabels 
		public void createRegisterTables() {
			connect();
			String sqlString;
			try {
					st = con.createStatement();
					sqlString = "CREATE TABLE IF NOT EXISTS userlogin "
					+ "( loginid INT NOT NULL,"
					+ "fname varchar(32) not null, "
					+ "lname varchar(32) not null, "
					+ "username varchar(32) not null, "
					+ "password varchar(32) not null, "
					+ "email varchar(30) NOT NULL,"	
					+ "PRIMARY KEY(loginid),"
					+ "unique(username) )";
					st.executeUpdate(sqlString);
			} catch (SQLException e) {
				
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, e.toString());
			}// end catch
		}
		
		private void createAuthenView() {
			try {
				
				PreparedStatement stmt = con.prepareStatement("CREATE VIEW authentication ( username, password)  " +
						"AS SELECT username, password FROM userlogin WHERE userlogin.loginid");				
				
				stmt.executeUpdate();
				
			}catch (Exception e) {	
				
				System.out.println("");
			}					
		}

	public void actionPerformed(ActionEvent event) {
				
		try {
			
			String user = usernamefield.getText().trim();
			String passw = passwordfield.getText().trim();
			
			usernamefield.setText("");
			passwordfield.setText("");
			
			String sql = "select username, password from authentication where username ='"+user+"' and password = '"+passw+"'";
			rs = st.executeQuery(sql);
			
			int count = 0;
			while (rs.next()){
				
				count = count + 1;
			}
			
			if (count == 1){
								
				new ServerFrame().setVisible(true);
			}
			else if (count > 1){
				
				//JOptionPane.showMessageDialog(null, "Duplicate User Found, Access Not Granted");
			}
			else {
				JOptionPane.showMessageDialog(null, "User Not Found ");
			}
		}	catch (Exception ex) {			
	}			
}

	class RegisterButton implements ActionListener
	{
	    public void actionPerformed(ActionEvent evt)
	    {
	    	registerpanel.add(registernumber);
	    	registerpanel.add(registerfield);
	    	registerpanel.add(firstname);
			registerpanel.add(fnamefield);
			registerpanel.add(lastname);
			registerpanel.add(lnamefield);
			registerpanel.add(r_username);
			registerpanel.add(r_usernamefield);
			registerpanel.add(r_password);
			registerpanel.add(r_passwordfield);
			registerpanel.add(email);
			registerpanel.add(emailfield);
			registerpanel.add(space);
			registerpanel.add(savebutton);
			
			JOptionPane.showMessageDialog(null, registerpanel);
	    	
	    }
	}  
	
	class InsertButton implements ActionListener
	{
	    public void actionPerformed(ActionEvent e)
	    {
	    	try {
	    		
	    	String registernummer = registerfield.getText().trim();
	    	String firstnavn = fnamefield.getText().trim();
			String lastnavn = lnamefield.getText().trim();
			String brugernavn = r_usernamefield.getText().trim();
			String passwrd = r_passwordfield.getText().trim();
			String brugeremail = emailfield.getText().trim();
			
			registerfield.setText("");
			fnamefield.setText("");
			lnamefield.setText("");
			r_usernamefield.setText("");
			r_passwordfield.setText("");
			emailfield.setText("");
			
			String sql1 = "INSERT INTO userlogin values ('"+registernummer+"', '"+firstnavn+"', '"+lastnavn+"', '"+brugernavn+"', '"+passwrd+"', '"+brugeremail+"')";  
	    	
			st.executeUpdate(sql1);
			
			JOptionPane.getRootFrame().dispose();
			
			JOptionPane.showMessageDialog(null, "You are register now!!");
			
	    	} catch (Exception X) {
				JOptionPane.showMessageDialog(null, "Violation!! Duplicate entry 'username' for key 'exist username'");
    		System.out.print(X);
	    	}	    	
	    }
	  }
	
	public static void main(String[] args) 
	{		
			new Login();
	}
}
